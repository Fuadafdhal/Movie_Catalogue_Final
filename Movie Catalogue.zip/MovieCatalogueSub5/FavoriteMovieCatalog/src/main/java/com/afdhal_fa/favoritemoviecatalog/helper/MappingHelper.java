package com.afdhal_fa.favoritemoviecatalog.helper;

import android.database.Cursor;

import com.afdhal_fa.favoritemoviecatalog.database.DatabaseContract;
import com.afdhal_fa.favoritemoviecatalog.entity.MovieData;

import java.util.ArrayList;


public class MappingHelper {
    public static ArrayList<MovieData> mapCursorToArrayList(Cursor notesCursor) {
        ArrayList<MovieData> notesList = new ArrayList<>();
        while (notesCursor.moveToNext()) {
            int id = notesCursor.getInt(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns._ID));
            String title = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.TITLE_MOVIE));
            String description = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.DESCRIPTION_MOVIE));
            String poster = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.POSTER_MOVIE));
            String banner = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.BANNER_MOVIE));
            double rating = notesCursor.getDouble(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.VOTE_AVERAGE_MOVIE));
            String language = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.ORIGINAL_LANGUAGE));
            String favorite = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.FAVORITE));
            notesList.add(new MovieData(id, title, description, poster,banner,rating,language,favorite));
        }
        return notesList;
    }

    public static MovieData mapCursorToObject(Cursor notesCursor) {
        notesCursor.moveToFirst();
        int id = notesCursor.getInt(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns._ID));
        String title = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.TITLE_MOVIE));
        String description = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.DESCRIPTION_MOVIE));
        String poster = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.POSTER_MOVIE));
        String banner = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.BANNER_MOVIE));
        double rating = notesCursor.getDouble(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.VOTE_AVERAGE_MOVIE));
        String language = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.ORIGINAL_LANGUAGE));
        String favorite = notesCursor.getString(notesCursor.getColumnIndexOrThrow(DatabaseContract.NoteColumns.FAVORITE));
        return new MovieData(id, title, description, poster, banner, rating, language, favorite);
    }
}
